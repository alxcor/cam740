#ifndef SNAP7_GLOBAL_H
#define SNAP7_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(SNAP7_LIBRARY)
#  define SNAP7_EXPORT Q_DECL_EXPORT
#else
#  define SNAP7_EXPORT Q_DECL_IMPORT
#endif

#endif // SNAP7_GLOBAL_H
